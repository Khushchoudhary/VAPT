# Phishing Email Templates

## 1. Urgency Template
Subject: Immediate Password Reset Required
Body:
Click here to reset your NMIMS password: http://<your_ip>

## 2. Reward Template
Subject: You’ve Won an iPhone!
Click here to claim: http://<your_ip>

## 3. Fear Template
Subject: Suspicious Login Detected
Reset password immediately: http://<your_ip>
